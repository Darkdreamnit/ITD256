
export ORACLE_SID=+ASM                                                                                                  

ORAENV_ASK='NO'                                                                                                         

. oraenv                                                                                                                

ORAENV_ASK=''                                                                                                           
SP2-0734: unknown command beginning "from v$arc..." - rest of line ignored.
SP2-0734: unknown command beginning "where (seq..." - rest of line ignored.
SP2-0734: unknown command beginning "where firs..." - rest of line ignored.
SP2-0734: unknown command beginning "New lines ..." - rest of line ignored.
