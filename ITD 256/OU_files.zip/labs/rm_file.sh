su - grid -c "$LABS/rm_asm_file.sh +DATA/ORCL/DATAFILE/bar93tbs01.dbf"          
