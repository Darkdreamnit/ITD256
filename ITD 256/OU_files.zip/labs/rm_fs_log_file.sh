rm -f "/u01/app/oracle/oradata/orcl/redo02.log"                                 
