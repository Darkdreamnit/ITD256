
rm "/u01/app/oracle/fast_recovery_area/ORCL/archivelog/2014_12_16/o1_mf_1_70_b8zswd68_.arc"                             
