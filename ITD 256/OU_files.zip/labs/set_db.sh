ORACLE_SID=orcl
ORAENV_ASK='NO'
. oraenv >>/dev/null
ORAENV_ASK=''

