update emp set sal = 3000 where empno = 7788;
update dept set dname = upper(dname) where deptno = 10;
commit;

